已复核的图像-标签样本，不是已划分的完整数据集。
0=hardhat（头部含安全帽）；1=no-hardhat（未戴安全帽头部）。
训练标签每行 class x_center y_center width height，后四项按原图宽高归一化，不含 confidence。
内置图为原创教学绘制，标签检查只能反映本练习设定；实际项目需统一口径并独立人工复核。
